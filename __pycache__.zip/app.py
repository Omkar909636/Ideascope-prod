from flask import Flask, render_template, request, redirect, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from groq import Groq
import re
import json

from models import db, User, Idea

app = Flask(__name__)
app.config["SECRET_KEY"] = "ideascopesecret"
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///database.db"

db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = "login"
login_manager.init_app(app)

client = Groq(api_key="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")

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

def is_unsafe(text):
    unsafe_words = ["fight","weapon","kill","attack","gang","riot","bomb","shoot","stab","violence","war","terror","gun"]
    return any(w in text.lower() for w in unsafe_words)

@app.route("/")
def landing():
    return render_template("landing.html")

@app.route("/register", methods=["GET","POST"])
def register():
    error = None
    if request.method == "POST":
        email = request.form["email"].strip().lower()
        password = request.form["password"]
        confirm = request.form["confirm"]

        if not email or not password:
            error = "All fields are required."
        elif password != confirm:
            error = "Passwords do not match."
        elif len(password) < 6:
            error = "Password must be at least 6 characters."
        elif User.query.filter_by(email=email).first():
            error = "An account with this email already exists."
        else:
            hashed = generate_password_hash(password)
            user = User(email=email, password=hashed)
            db.session.add(user)
            db.session.commit()
            return redirect("/login")

    return render_template("register.html", error=error)


@app.route("/login", methods=["GET","POST"])
def login():
    error = None
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        user = User.query.filter_by(email=email).first()

        if not user:
            error = "No account found with this email."
        elif not check_password_hash(user.password, password):
            error = "Incorrect password."
        else:
            login_user(user)
            return redirect("/dashboard")

    return render_template("login.html", error=error)


@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect("/")



@app.route("/questions", methods=["POST"])
@login_required
def questions():
    data = request.json
    if not data or "idea" not in data or not data["idea"].strip():
        return jsonify({"error": "Idea cannot be empty."}), 400

    idea = data["idea"]

    if is_unsafe(idea):
        return jsonify({"unsafe":True,"message":"Unsafe idea. Please reframe."})

    # Use a stronger prompt for questions
    prompt = f"""
    You are a senior startup analyst.
    Your goal: Ask 3 critical, specific questions to validate this startup idea.
    
    Idea: {idea}
    
    Output JSON ONLY with format:
    {{"questions": ["Question 1", "Question 2", "Question 3"]}}
    """

    try:
        res = client.chat.completions.create(
            model="llama-3.1-8b-instant",
            messages=[{"role":"user","content":prompt}],
            response_format={"type": "json_object"}
        )
        data = json.loads(res.choices[0].message.content)
        return jsonify({"unsafe":False,"questions":data.get("questions", [])})
    except Exception as e:
        print(f"Error calling AI API for questions: {e}")
        return jsonify({"unsafe":False,"questions":[
            "Who exactly is the target customer?",
            "How do you plan to acquire users?",
            "What is the core revenue model?"
        ]})

@app.route("/analyze", methods=["POST"])
@login_required
def analyze():
    data = request.json
    if not data or "idea" not in data or not data["idea"].strip():
        return jsonify({"error": "Idea cannot be empty."}), 400
        
    idea = data["idea"]
    answers = data.get("answers", [])

    context = ""
    for i,a in enumerate(answers):
        context += f"Answer {i+1}: {a}\n"

    # Much more detailed prompt to get 'well researched data' simulation
    prompt = f"""
    Role: Expert VC & Market Researcher.
    Task: rigorous analysis of a startup idea.
    
    Startup Idea: {idea}
    Founder Clarifications:
    {context}
    
    Provide a detailed analysis in JSON format.
    The "market", "users", "problem", "risk", "suggestion" fields must contain SPECIFIC data points, potential market size numbers (TAM/SAM), or concrete examples. Do not be vague.
    
    JSON Format:
    {{
        "score": <int 0-10>,
        "market": "<Specific market size estimation and growth trend. E.g. 'Global EdTech market is $120B, growing at 15% CAGR...'>",
        "users": "<Specific user persona and their behavior. E.g. 'Gen Z students aged 18-24 who spend 4h+ on mobile...'>",
        "problem": "<The acute pain point being solved.>",
        "risk": "<The single most dangerous failure mode (e.g. 'High CAC due to competition').>",
        "suggestion": "<One high-impact strategic move to execute immediately.>",
        "detailed_analysis": "<A 400-word full report in Markdown. internal structure: ## Executive Summary, ## Market Analysis (include numbers), ## Competitive Landscape, ## Revenue Model, ## Verdict.>"
    }}
    """

    try:
        res = client.chat.completions.create(
            model="llama-3.3-70b-versatile", # Using 70b for better reasoning/data
            messages=[{"role":"user","content":prompt}],
            response_format={"type": "json_object"}
        )
        analysis_data = json.loads(res.choices[0].message.content)
        
        # Defaults
        score = analysis_data.get("score", 5)
        text = analysis_data.get("detailed_analysis", "Analysis could not be generated.")

    except Exception as e:
        print(f"Error calling AI API: {e}")
        # Fallback to 8b if 70b fails or other error
        try:
             res = client.chat.completions.create(
                model="llama-3.1-8b-instant",
                messages=[{"role":"user","content":prompt}],
                response_format={"type": "json_object"}
            )
             analysis_data = json.loads(res.choices[0].message.content)
             score = analysis_data.get("score", 5)
             text = analysis_data.get("detailed_analysis", "Analysis generated via fallback.")
        except Exception as e2:
             print(f"Fallback Error: {e2}")
             return jsonify({"error": "Failed to generate analysis."}), 500

    # Ensure score is int
    try:
        score = int(score)
    except:
        score = 5
    score = max(0, min(10, score))

    # Save to DB
    # Save to DB - storing full JSON data now to reconstruct UI cards later
    # We use json.dumps to store the dict as a string
    idea_obj = Idea(
        title=idea[:50],
        content=idea,
        analysis=json.dumps(analysis_data), 
        score=score,
        user_id=current_user.id
    )
    db.session.add(idea_obj)
    db.session.commit()

    return jsonify(analysis_data)

# --- CONFIGURATION ---
ADMIN_EMAILS = ["admin@ideascope.com", "test@test.com"] # Add your email here to access /admin

@app.route("/dashboard")
@login_required
def dashboard():
    # Fetch user history, newest first
    history = Idea.query.filter_by(user_id=current_user.id).order_by(Idea.id.desc()).all()
    is_admin = current_user.email in ADMIN_EMAILS
    return render_template("index.html", history=history, is_admin=is_admin)

@app.route("/admin")
@login_required
def admin():
    if current_user.email not in ADMIN_EMAILS:
        return "Access Denied", 403
    
    users = User.query.all()
    ideas = Idea.query.order_by(Idea.id.desc()).all()
    return render_template("admin.html", users=users, ideas=ideas)

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
